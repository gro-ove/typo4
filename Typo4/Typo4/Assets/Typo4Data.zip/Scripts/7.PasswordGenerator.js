"noinput"
console.log(Math.random().toString(36).slice(-8))